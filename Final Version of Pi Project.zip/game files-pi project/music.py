from pygame import mixer # Load the required library

mixer.init()
mixer.music.load('C:/Users/matthew alvidrez/Desktop/python things/music in py/hyrule castle.mp3')
mixer.music.play()

